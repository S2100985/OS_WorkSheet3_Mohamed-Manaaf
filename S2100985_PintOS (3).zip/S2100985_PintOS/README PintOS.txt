# 21076191_PintOS submission

## Name
PintOS Run

## Description
In this project there are screenshots of the systems calls and the qemu popups that are shown after running the required codes in the ubuntu terminal. Inluding that there will also be the PintOS folder which contains the files to run the project. The aim of the project is to enable pintOS and run a few system calls. 

## Visuals
The relevant screenshots are in the zipped folder.

## Installation
Ubuntu Operating system was installed and all the commands were run using the ubuntu terminal.

## Support
ALl the required help was handed out by the UWE Lab reports

## Project status
There will be no further changes to these set of files
